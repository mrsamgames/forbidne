﻿using System;
using System.Windows.Forms;

class Program
{
    static void Main()
    {
        MessageBox.Show("Gangsta freemasonry made me do it", "MasonObfuscator");
        Environment.Exit(0);
    }
}

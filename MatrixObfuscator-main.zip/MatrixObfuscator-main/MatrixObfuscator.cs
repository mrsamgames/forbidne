﻿using System;
using System.Windows.Forms;

class Program
{
    static void Main()
    {
        MessageBox.Show("Gangsta freemasonry made me do it", "MatrixObfuscator");
        Environment.Exit(0);
    }
}

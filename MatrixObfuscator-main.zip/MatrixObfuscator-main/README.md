# MatrixObfuscator
![OnOlthv](https://github.com/MasonGroup/MatrixObfuscator/assets/95870255/6f912ab4-b2e1-4072-a083-d598d567493b)
---
The most powerful Obfuscator in history
---
It converts your code like this
![image](https://github.com/MasonGroup/MatrixObfuscator/assets/95870255/33fab165-b5ab-4236-8f8f-57ae96f7298d)
---
To this way
![image](https://github.com/MasonGroup/MatrixObfuscator/assets/95870255/83ca60c6-ff9b-4b35-a4dd-aa6a5f9faaaf)
---
```sh
"We hereby declare that we disclaim any liability for any improper use of the software. Thank you for your understanding."

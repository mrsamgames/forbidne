#pragma once
#include "Utils.h"

VOID PrintKeyC(PBYTE pKey, SIZE_T SizeOfKey);
VOID PrintShellcodeC(PBYTE pShellcode, SIZE_T ShellcodeSize);
VOID PrintShellcodePowerShell(PBYTE pShellcode, SIZE_T ShellcodeSize);